Edite o arquivo start.bat e coloque o endere�o da sua wallet no 
lugar de NEUgftLSYimfuFe49LsmNeFUTkaewt5Ucf1fotjv8M71JxtB2KFEJc8MeRW8yPLpCUPzRuwCvoxDtPeCxJ5Cy1BrVHeJ7k2
